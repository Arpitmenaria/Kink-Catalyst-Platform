import { createSlice, createAsyncThunk } from '@reduxjs/toolkit';
import { apiRequest } from '../../services/api';
import { blockUser } from './usersSlice';

// The same post can exist as separate copies in the main feed, the logged-in
// user's own post list, and a viewed profile's post list simultaneously —
// mutate every copy that matches, not just the first one found, or lists
// that didn't get the update go stale (e.g. comments posted from a profile
// page never showing there once the feed already holds its own copy).
function forEachMatchingPost(state, postId, fn) {
  for (const list of [state.posts, state.myPosts, state.viewedPosts]) {
    const post = list.find(p => {
      const pId = p._id ?? p.id ?? p.postId;
      return pId === postId;
    });
    if (post) fn(post);
  }
  // The single-post modal holds its own copy — keep it in sync too, so
  // reacting/commenting from the modal updates what's on screen.
  if (state.postDetail) {
    const detailId = state.postDetail._id ?? state.postDetail.id ?? state.postDetail.postId;
    if (detailId === postId) fn(state.postDetail);
  }
}

// A comment fetch/resync can land while our own just-posted comment is still
// mid-flight (commentPost hasn't resolved yet) — if the server's response
// doesn't include it yet, replacing wholesale would make it flash away and
// briefly show "No comments yet" again. Keep any not-yet-confirmed optimistic
// entry the fresh list doesn't already have.
function mergeFreshComments(post, comments) {
  const pending = Array.isArray(post.comments)
    ? post.comments.filter(c => c?.pending && !comments.some(sc => (sc._id ?? sc.id) === (c._id ?? c.id)))
    : [];
  post.comments = [...comments, ...pending];
  post.commentsCount = post.comments.length;
  post.commentsLoaded = true;
}

function findComment(comments, commentId) {
  for (const c of comments) {
    if ((c._id ?? c.id) === commentId) return c;
    if (Array.isArray(c.replies)) {
      const reply = c.replies.find(r => (r._id ?? r.id) === commentId);
      if (reply) return reply;
    }
  }
  return null;
}

export function normalizePost(p) {
  // The feed/list endpoint only sends a comment COUNT, not the actual
  // comments — full comment objects are fetched on-demand (fetchPostComments)
  // when a user opens a post's comment section. `commentsLoaded` tracks
  // whether `comments` below is real data yet or just a count-shaped array.
  const commentsIsCount = typeof p.comments === 'number';
  return {
    ...p,
    likes: Array.isArray(p.likes) ? p.likes : [],
    likesCount: typeof p.likesCount === 'number' ? p.likesCount : (Array.isArray(p.likes) ? p.likes.length : 0),
    myReaction: p.myReaction ?? (p.isLiked ? 'like' : null),
    recentReactors: Array.isArray(p.recentReactors) ? p.recentReactors : [],
    comments: commentsIsCount
      ? new Array(p.comments).fill(null)
      : (Array.isArray(p.comments) ? p.comments : []),
    commentsCount: commentsIsCount ? p.comments : (Array.isArray(p.comments) ? p.comments.length : 0),
    commentsLoaded: !commentsIsCount,
    shares: typeof p.shares === 'number'
      ? new Array(p.shares).fill(null)
      : (Array.isArray(p.shares) ? p.shares : []),
    isReported: p.isReported ?? false,
  };
}

const VIDEO_EXT = /\.(mp4|webm|ogg|mov|avi|mkv)(\?|#|$)/i;

function detectMediaType(url = '', hint = null) {
  if (hint === 'video') return 'video';
  if (VIDEO_EXT.test(url)) return 'video';
  return 'image';
}

// /api/users/me/posts field mapping → PostCard shape
function normalizeMyPost(p) {
  // Build media array, normalizing video type regardless of what the API sends
  let rawMedia = [];
  if (Array.isArray(p.media) && p.media.length > 0) {
    // API already sent media[] — re-check type for each item
    rawMedia = p.media;
  } else {
    // Build from flat fields
    if (p.video) rawMedia.push({ url: p.video, type: 'video' });
    if (Array.isArray(p.videos)) p.videos.filter(Boolean).forEach(url => rawMedia.push({ url, type: 'video' }));
    if (Array.isArray(p.images)) p.images.filter(Boolean).forEach(url => rawMedia.push({ url }));
  }
  const media = rawMedia
    .filter(item => item?.url)
    .map(item => ({ ...item, type: detectMediaType(item.url, item.type) }));

  return {
    ...p,
    // author.name → author.fullName (PostCard reads fullName)
    author: p.author
      ? { ...p.author, fullName: p.author.fullName ?? p.author.name ?? '' }
      : p.author,
    // content → caption (PostCard reads caption)
    caption: p.caption ?? p.content ?? '',
    media,
    // likes is a number from this API — keep as-is for PostCard's isStatic path
    likes: typeof p.likes === 'number' ? p.likes : (Array.isArray(p.likes) ? p.likes : 0),
    myReaction: p.myReaction ?? (p.isLiked ? 'like' : null),
    comments: typeof p.comments === 'number'
      ? new Array(p.comments).fill(null)
      : (Array.isArray(p.comments) ? p.comments : []),
    commentsCount: typeof p.comments === 'number' ? p.comments : (Array.isArray(p.comments) ? p.comments.length : 0),
    commentsLoaded: typeof p.comments !== 'number',
    shares: typeof p.shares === 'number'
      ? new Array(p.shares).fill(null)
      : (Array.isArray(p.shares) ? p.shares : []),
    isReported: p.isReported ?? false,
  };
}

export const fetchFeedPosts = createAsyncThunk(
  'posts/fetchFeed',
  async ({ page = 1, limit = 10 } = {}, { getState, rejectWithValue }) => {
    try {
      const { token } = getState().auth;
      const data = await apiRequest(`/api/posts?page=${page}&limit=${limit}`, { token });
      const posts = (data.posts ?? []).map(normalizePost);
      const total = data.total ?? 0;
      const hasMore = posts.length >= limit && (page * limit) < total;
      return { posts, total, page, hasMore };
    } catch (err) {
      return rejectWithValue(err.message);
    }
  }
);

// Single post + its full comment thread — powers the post-detail modal opened
// from a notification, so it works for any post regardless of feed pagination.
export const fetchPostById = createAsyncThunk(
  'posts/fetchById',
  async (postId, { getState, rejectWithValue }) => {
    try {
      const { token } = getState().auth;
      const data = await apiRequest(`/api/posts/${postId}`, { token });
      return normalizePost(data.post ?? data);
    } catch (err) {
      return rejectWithValue({ status: err.status, message: err.message });
    }
  }
);

export const fetchMyPosts = createAsyncThunk(
  'posts/fetchMyPosts',
  async ({ page = 1, limit = 10 } = {}, { getState, rejectWithValue }) => {
    try {
      const { token } = getState().auth;
      const data = await apiRequest(`/api/users/me/posts?page=${page}&limit=${limit}`, { token });
      return {
        posts: (data.posts ?? []).map(normalizeMyPost),
        total: data.total ?? 0,
        page: data.page ?? page,
        hasMore: data.hasMore ?? false,
      };
    } catch (err) {
      return rejectWithValue(err.message);
    }
  }
);

// Lightweight count-only fetch for the navbar's "Total Posts" stat — must NOT
// touch state.myPosts, since ProfilePage's fetchMyPosts (paged list) can be
// in flight at the same time and a shared reducer would clobber it.
export const fetchMyPostsCount = createAsyncThunk(
  'posts/fetchMyPostsCount',
  async (_, { getState, rejectWithValue }) => {
    try {
      const { token } = getState().auth;
      const data = await apiRequest(`/api/users/me/posts?page=1&limit=1`, { token });
      return { total: data.total ?? 0 };
    } catch (err) {
      return rejectWithValue(err.message);
    }
  }
);

export const likePost = createAsyncThunk(
  'posts/like',
  async ({ postId, userId, reaction = 'like', remove = false }, { getState, rejectWithValue }) => {
    console.log('🚀🚀🚀 [likePost] ASYNC FUNCTION STARTED 🚀🚀🚀');
    console.log('🚀 [likePost] Thunk executing:', { postId, userId, reaction, remove });
    try {
      const { token } = getState().auth;
      const url = `/api/posts/${postId}/like`;
      console.log('📡 [likePost] Calling API:', url, { reaction, remove });
      const data = await apiRequest(url, {
        method: 'POST',
        token,
        body: { reaction, remove },
      });
      console.log('✅ [likePost] API Success:', data);
      return {
        postId,
        liked: data.liked,
        likesCount: data.likesCount,
        recentReactors: data.recentReactors,
        myReaction: data.myReaction ?? (data.liked ? reaction : null),
        userId,
      };
    } catch (err) {
      console.error('❌ [likePost] API Error:', err.message);
      return rejectWithValue({ postId, userId, message: err.message });
    }
  }
);

export const fetchPostComments = createAsyncThunk(
  'posts/fetchComments',
  async (postId, { getState, rejectWithValue }) => {
    try {
      const { token } = getState().auth;
      const data = await apiRequest(`/api/posts/${postId}/comments`, { token });
      // Backend can include null/malformed entries in this array (e.g. a
      // deleted comment left as a placeholder) — strip them here, at the
      // point they enter Redux, instead of every consumer needing its own guard.
      return { postId, comments: (data.comments ?? []).filter(Boolean) };
    } catch (err) {
      return rejectWithValue({ postId, message: err.message });
    }
  }
);

// Silent background resync for an open comments panel — same call as
// fetchPostComments, but deliberately doesn't touch commentsLoadingIds (no
// spinner flicker every poll). Backstops the live comment:created socket
// event in case it's dropped or never actually reaches this client; mirrors
// the identical syncMessages pattern already used for the chat window.
export const syncPostComments = createAsyncThunk(
  'posts/syncComments',
  async (postId, { getState, rejectWithValue }) => {
    try {
      const { token } = getState().auth;
      const data = await apiRequest(`/api/posts/${postId}/comments`, { token });
      // Backend can include null/malformed entries in this array (e.g. a
      // deleted comment left as a placeholder) — strip them here, at the
      // point they enter Redux, instead of every consumer needing its own guard.
      return { postId, comments: (data.comments ?? []).filter(Boolean) };
    } catch (err) {
      return rejectWithValue({ postId, message: err.message });
    }
  }
);

// Reactions modal — full per-reaction-type list, paginated. Fetched with a
// generous limit and no `reaction` filter so tab counts (All / 👍 / 🎉 / …)
// can be computed client-side by grouping `likes` by `.reaction`, without a
// separate probe request per type.
export const fetchPostLikes = createAsyncThunk(
  'posts/fetchLikes',
  async ({ postId, page = 1, limit = 100 }, { getState, rejectWithValue }) => {
    try {
      const { token } = getState().auth;
      const data = await apiRequest(`/api/posts/${postId}/likes?page=${page}&limit=${limit}`, { token });
      return { postId, total: data.total ?? 0, page: data.page ?? page, likes: data.likes ?? [] };
    } catch (err) {
      return rejectWithValue({ postId, message: err.message });
    }
  }
);

export const commentPost = createAsyncThunk(
  'posts/comment',
  async ({ postId, text, mentions }, { getState, rejectWithValue }) => {
    try {
      const { token } = getState().auth;
      const data = await apiRequest(`/api/posts/${postId}/comments`, {
        method: 'POST',
        body: { text, mentions: mentions ?? [] },
        token,
      });
      return { postId, comment: data.comment };
    } catch (err) {
      return rejectWithValue(err.message);
    }
  }
);

export const likeComment = createAsyncThunk(
  'posts/likeComment',
  async ({ postId, commentId }, { getState, rejectWithValue }) => {
    try {
      const { token } = getState().auth;
      const data = await apiRequest(`/api/posts/${postId}/comments/${commentId}/like`, { method: 'POST', token });
      return { postId, commentId, liked: data.liked, likesCount: data.likesCount };
    } catch (err) {
      return rejectWithValue({ postId, commentId, message: err.message });
    }
  }
);

export const replyToComment = createAsyncThunk(
  'posts/replyToComment',
  // replyingTo: id of the specific reply this is answering (vs. the parent
  // comment in general) — lets the UI thread it right after that reply
  // instead of always at the end of the flat chronological list. No-ops
  // until the backend actually stores/returns this field on replies.
  async ({ postId, commentId, text, mentions, replyingTo }, { getState, rejectWithValue }) => {
    try {
      const { token } = getState().auth;
      const data = await apiRequest(`/api/posts/${postId}/comments/${commentId}/replies`, {
        method: 'POST',
        body: { text, mentions: mentions ?? [], replyingTo: replyingTo ?? null },
        token,
      });
      return { postId, commentId, reply: data.reply };
    } catch (err) {
      return rejectWithValue(err.message);
    }
  }
);

// ── Comment/reply edit, delete, report — author-only for edit/delete, any
// user but the author for report (backend 400s a self-report). Delete is a
// soft-delete: the comment/reply stays in place (so replies threaded under it
// don't orphan) but flips `deleted: true`, rendered as "[deleted]".
export const editComment = createAsyncThunk(
  'posts/editComment',
  async ({ postId, commentId, text, mentions }, { getState, rejectWithValue }) => {
    try {
      const { token } = getState().auth;
      const data = await apiRequest(`/api/posts/${postId}/comments/${commentId}`, {
        method: 'PATCH',
        body: { text, mentions: mentions ?? [] },
        token,
      });
      return {
        postId,
        commentId,
        text: data.comment?.text ?? text,
        mentions: data.comment?.mentions ?? mentions ?? [],
        editedAt: data.comment?.editedAt ?? new Date().toISOString(),
      };
    } catch (err) {
      return rejectWithValue({ postId, commentId, message: err.message });
    }
  }
);

export const deleteComment = createAsyncThunk(
  'posts/deleteComment',
  async ({ postId, commentId }, { getState, rejectWithValue }) => {
    try {
      const { token } = getState().auth;
      await apiRequest(`/api/posts/${postId}/comments/${commentId}`, { method: 'DELETE', token });
      return { postId, commentId };
    } catch (err) {
      return rejectWithValue({ postId, commentId, message: err.message });
    }
  }
);

export const reportComment = createAsyncThunk(
  'posts/reportComment',
  async ({ postId, commentId, reason }, { getState, rejectWithValue }) => {
    try {
      const { token } = getState().auth;
      await apiRequest(`/api/posts/${postId}/comments/${commentId}/report`, {
        method: 'POST',
        body: { reason },
        token,
      });
      return { postId, commentId };
    } catch (err) {
      return rejectWithValue(err.message);
    }
  }
);

export const editReply = createAsyncThunk(
  'posts/editReply',
  async ({ postId, commentId, replyId, text, mentions }, { getState, rejectWithValue }) => {
    try {
      const { token } = getState().auth;
      const data = await apiRequest(`/api/posts/${postId}/comments/${commentId}/replies/${replyId}`, {
        method: 'PATCH',
        body: { text, mentions: mentions ?? [] },
        token,
      });
      return {
        postId,
        replyId,
        text: data.reply?.text ?? text,
        mentions: data.reply?.mentions ?? mentions ?? [],
        editedAt: data.reply?.editedAt ?? new Date().toISOString(),
      };
    } catch (err) {
      return rejectWithValue({ postId, commentId, replyId, message: err.message });
    }
  }
);

export const deleteReply = createAsyncThunk(
  'posts/deleteReply',
  async ({ postId, commentId, replyId }, { getState, rejectWithValue }) => {
    try {
      const { token } = getState().auth;
      await apiRequest(`/api/posts/${postId}/comments/${commentId}/replies/${replyId}`, { method: 'DELETE', token });
      return { postId, replyId };
    } catch (err) {
      return rejectWithValue({ postId, commentId, replyId, message: err.message });
    }
  }
);

export const reportReply = createAsyncThunk(
  'posts/reportReply',
  async ({ postId, commentId, replyId, reason }, { getState, rejectWithValue }) => {
    try {
      const { token } = getState().auth;
      await apiRequest(`/api/posts/${postId}/comments/${commentId}/replies/${replyId}/report`, {
        method: 'POST',
        body: { reason },
        token,
      });
      return { postId, replyId };
    } catch (err) {
      return rejectWithValue(err.message);
    }
  }
);

export const createPost = createAsyncThunk(
  'posts/create',
  // mediaFile: single video file. mediaFiles: one or more images (multi-photo
  // posts). Merge into one deduped list so a caller passing the same file as
  // both (video tab did this) doesn't upload it twice under the 'media' field.
  async ({ caption, mediaFile, mediaFiles, visibility = 'anyone', mentions }, { getState, rejectWithValue }) => {
    try {
      const { token } = getState().auth;
      const formData = new FormData();
      if (caption?.trim()) formData.append('caption', caption.trim());
      formData.append('visibility', visibility);
      if (mentions?.length) formData.append('mentions', JSON.stringify(mentions));
      const allMedia = [...(mediaFile ? [mediaFile] : []), ...(mediaFiles ?? [])];
      const uniqueMedia = allMedia.filter((f, i) => allMedia.indexOf(f) === i);
      uniqueMedia.forEach(file => formData.append('media', file));

      const data = await apiRequest('/api/posts', {
        method: 'POST',
        body: formData,
        token,
        isFormData: true,
      });
      return normalizePost(data.post);
    } catch (err) {
      return rejectWithValue(err.message);
    }
  }
);

export const editPost = createAsyncThunk(
  'posts/edit',
  async ({ postId, caption, visibility, mentions }, { getState, rejectWithValue }) => {
    try {
      const { token } = getState().auth;
      const data = await apiRequest(`/api/posts/${postId}`, {
        method: 'PATCH',
        body: { caption, visibility, mentions: mentions ?? [] },
        token,
      });
      return {
        postId,
        caption: data.post?.caption ?? caption,
        visibility: data.post?.visibility ?? visibility,
        mentions: data.post?.mentions ?? mentions ?? [],
      };
    } catch (err) {
      return rejectWithValue(err.message);
    }
  }
);

export const deletePost = createAsyncThunk(
  'posts/delete',
  async (postId, { getState, rejectWithValue }) => {
    try {
      const { token } = getState().auth;
      await apiRequest(`/api/posts/${postId}`, { method: 'DELETE', token });
      return { postId };
    } catch (err) {
      return rejectWithValue(err.message);
    }
  }
);

export const fetchReportReasons = createAsyncThunk(
  'posts/fetchReportReasons',
  async (_, { rejectWithValue }) => {
    try {
      const data = await apiRequest('/api/posts/report-reasons');
      return data.reasons ?? [];
    } catch (err) {
      return rejectWithValue(err.message);
    }
  }
);

export const reportPost = createAsyncThunk(
  'posts/report',
  async ({ postId, reason }, { getState, rejectWithValue }) => {
    try {
      const { token } = getState().auth;
      await apiRequest(`/api/posts/${postId}/report`, {
        method: 'POST',
        body: { reason },
        token,
      });
      return { postId };
    } catch (err) {
      return rejectWithValue(err.message);
    }
  }
);

export const reportUser = createAsyncThunk(
  'posts/reportUser',
  async ({ userId, reason }, { getState, rejectWithValue }) => {
    try {
      const { token } = getState().auth;
      await apiRequest(`/api/users/${userId}/report`, {
        method: 'POST',
        body: { reason },
        token,
      });
      return { userId };
    } catch (err) {
      return rejectWithValue(err.message);
    }
  }
);

export const sharePost = createAsyncThunk(
  'posts/share',
  async (postId, { getState, rejectWithValue }) => {
    try {
      const { token } = getState().auth;
      const data = await apiRequest(`/api/posts/${postId}/share`, { method: 'POST', token });
      return { postId, sharesCount: data.sharesCount };
    } catch (err) {
      return rejectWithValue(err.message);
    }
  }
);

const postsSlice = createSlice({
  name: 'posts',
  initialState: {
    posts: [],
    loading: false,
    error: null,
    feedTotal: 0,
    feedPage: 1,
    feedHasMore: true,
    myPosts: [],
    myPostsTotal: 0,
    myPostsLoading: false,
    myPostsHasMore: false,
    viewedPosts: [],
    postDetail: null,          // single post shown in the detail modal
    postDetailLoading: false,
    postDetailError: null,     // { status, message } on 404/403
    likingIds: [],
    commentingId: null,
    commentsLoadingIds: [],
    postLikes: {}, // { [postId]: { total, items: [], page, hasMore, loading } } — Reactions modal data
    sharingId: null,
    creating: false,
    editingId: null,
    deletingId: null,
    deletingCommentId: null, // id of the comment/reply currently being deleted (confirm-modal spinner)
    reportReasons: [],
    reasonsLoading: false,
    reportSubmitting: false,
  },
  reducers: {
    setViewedPosts(state, action) {
      state.viewedPosts = action.payload ?? [];
    },
    clearPostDetail(state) {
      state.postDetail = null;
      state.postDetailLoading = false;
      state.postDetailError = null;
    },
    addPostRealtime(state, action) {
      const postData = action.payload;
      const incomingId = postData.postId ?? postData._id;

      // AGGRESSIVE DEDUP: Remove the post from ALL lists if it exists anywhere
      for (const list of [state.posts, state.myPosts, state.viewedPosts]) {
        const index = list.findIndex(p => {
          const pId = p._id ?? p.id ?? p.postId;
          return pId === incomingId;
        });
        if (index !== -1) {
          list.splice(index, 1);
        }
      }
      // Also check post detail
      if (state.postDetail) {
        const detailId = state.postDetail._id ?? state.postDetail.id ?? state.postDetail.postId;
        if (detailId === incomingId) {
          // Don't remove, just note it
        }
      }

      // Normalize and add once. Must carry the same fields normalizePost()
      // guarantees for a REST-fetched post — PostCard reads likesCount (not
      // likeCount), comments as a real array, etc. A live post missing these
      // silently broke the "People react" row (gated on likesCount > 0) and
      // the comments panel for any post that arrived via this event instead
      // of the initial feed fetch, until the next full refresh re-fetched it
      // properly.
      const normalizedPost = {
        _id: incomingId,
        author: {
          _id: postData.userId ?? postData.author?._id,
          fullName: postData.fullName ?? postData.author?.fullName,
          avatar: postData.avatar ?? postData.author?.avatar,
          location: postData.location ?? postData.author?.location ?? '',
        },
        caption: postData.caption ?? postData.content,
        mentions: postData.mentions ?? [],
        media: postData.media ?? postData.images ?? [],
        createdAt: postData.createdAt ?? new Date().toISOString(),
        likeCount: postData.likeCount ?? 0,
        likesCount: postData.likeCount ?? postData.likesCount ?? 0,
        likes: [],
        myReaction: null,
        recentReactors: [],
        commentCount: postData.commentCount ?? 0,
        commentsCount: postData.commentCount ?? postData.commentsCount ?? 0,
        comments: [],
        commentsLoaded: true,
        shareCount: postData.shareCount ?? 0,
        shares: [],
        liked: false,
        isReported: false,
        visibility: postData.visibility ?? 'anyone',
      };
      state.posts.unshift(normalizedPost);
    },
    removePostRealtime(state, action) {
      const postId = action.payload;
      state.posts = state.posts.filter(p => (p._id ?? p.id) !== postId);
      if (state.postDetail?._id === postId || state.postDetail?.id === postId) {
        state.postDetail = null;
      }
    },
    updatePostLikeCount(state, action) {
      const { postId, likeCount } = action.payload;
      // Search all post lists
      for (const list of [state.posts, state.myPosts, state.viewedPosts]) {
        const post = list.find(p => {
          const pId = p._id ?? p.id ?? p.postId;
          return pId === postId || pId === (postId?.postId);
        });
        if (post) {
          post.likeCount = likeCount;
          post.likesCount = likeCount;
        }
      }
      // Also update post detail modal
      if (state.postDetail) {
        const pId = state.postDetail._id ?? state.postDetail.id ?? state.postDetail.postId;
        if (pId === postId || pId === (postId?.postId)) {
          state.postDetail.likeCount = likeCount;
          state.postDetail.likesCount = likeCount;
        }
      }
    },
    addCommentRealtime(state, action) {
      const { postId, comment } = action.payload;
      if (!comment) return;
      const normalizedComment = {
        _id: comment._id ?? comment.id,
        text: comment.text ?? comment.content ?? '',
        author: comment.author ?? { _id: comment.userId, fullName: comment.fullName },
        createdAt: comment.createdAt ?? new Date().toISOString(),
        likes: comment.likes ?? comment.likeCount ?? 0,
        likeCount: comment.likeCount ?? comment.likes ?? 0,
        replies: comment.replies ?? [],
      };
      // Search all post lists for matching postId (handles both _id and postId formats)
      for (const list of [state.posts, state.myPosts, state.viewedPosts]) {
        const post = list.find(p => {
          const pId = p._id ?? p.id ?? p.postId;
          return pId === postId || pId === (postId?.postId);
        });
        if (post) {
          // Convert comment count to empty array if needed (for real-time posts)
          if (typeof post.comments === 'number') post.comments = [];
          else if (!Array.isArray(post.comments)) post.comments = [];
          // Dedup — the commenting user's own optimistic push (commentPost.fulfilled)
          // can land alongside this live echo for the same comment.
          if (!post.comments.some(c => c && (c._id ?? c.id) === normalizedComment._id)) {
            post.comments.push(normalizedComment);
            post.commentCount = (post.commentCount ?? 0) + 1;
            // PostCard reads `commentsCount` (plural) — this was never updated,
            // so the visible count silently stayed stale until a full refetch.
            post.commentsCount = (post.commentsCount ?? 0) + 1;
          }
        }
      }
      // Also update post detail modal
      const postDetail = state.postDetail;
      if (postDetail) {
        const pId = postDetail._id ?? postDetail.id ?? postDetail.postId;
        if (pId === postId || pId === (postId?.postId)) {
          if (typeof postDetail.comments === 'number') postDetail.comments = [];
          else if (!Array.isArray(postDetail.comments)) postDetail.comments = [];
          if (!postDetail.comments.some(c => c && (c._id ?? c.id) === normalizedComment._id)) {
            postDetail.comments.push(normalizedComment);
            postDetail.commentCount = (postDetail.commentCount ?? 0) + 1;
            postDetail.commentsCount = (postDetail.commentsCount ?? 0) + 1;
          }
        }
      }
    },
    updateCommentLikeCount(state, action) {
      const { postId, commentId, likeCount } = action.payload;
      const post = state.posts.find(p => (p._id ?? p.id) === postId);
      if (post?.comments) {
        const comment = post.comments.find(c => (c._id ?? c.id) === commentId);
        if (comment) comment.likeCount = likeCount;
      }
      if ((state.postDetail?._id ?? state.postDetail?.id) === postId) {
        const comment = state.postDetail.comments?.find(c => (c._id ?? c.id) === commentId);
        if (comment) comment.likeCount = likeCount;
      }
    },
    // Socket: someone (possibly us, echoed back) edited/deleted a comment or reply.
    // findComment searches both top-level comments and nested replies by id,
    // so the same handler works regardless of which one this is.
    updateCommentRealtime(state, action) {
      const { postId, commentId, text, mentions, editedAt } = action.payload;
      forEachMatchingPost(state, postId, (post) => {
        const c = findComment(post.comments, commentId);
        if (c) { c.text = text ?? c.text; c.mentions = mentions ?? c.mentions; c.editedAt = editedAt ?? c.editedAt; }
      });
    },
    deleteCommentRealtime(state, action) {
      const { postId, commentId } = action.payload;
      forEachMatchingPost(state, postId, (post) => {
        const c = findComment(post.comments, commentId);
        if (c) { c.deleted = true; c.text = ''; }
        post.commentsCount = Math.max(0, (post.commentsCount ?? 0) - 1);
      });
    },
    updateReplyRealtime(state, action) {
      const { postId, replyId, text, mentions, editedAt } = action.payload;
      forEachMatchingPost(state, postId, (post) => {
        const r = findComment(post.comments, replyId);
        if (r) { r.text = text ?? r.text; r.mentions = mentions ?? r.mentions; r.editedAt = editedAt ?? r.editedAt; }
      });
    },
    deleteReplyRealtime(state, action) {
      const { postId, replyId } = action.payload;
      forEachMatchingPost(state, postId, (post) => {
        const r = findComment(post.comments, replyId);
        if (r) { r.deleted = true; r.text = ''; }
      });
    },
    // Auto-hidden (5+ reports) for the post's own author only — unlike
    // removePostRealtime, this keeps the post in place so they can still see
    // it, just flagged so PostCard can show a "hidden from public" notice.
    // Everyone else gets the normal removePostRealtime instead (see socket.js).
    markPostHiddenRealtime(state, action) {
      const postId = action.payload;
      forEachMatchingPost(state, postId, (post) => { post.hiddenFromPublic = true; });
    },
  },
  extraReducers: (builder) => {
    builder
      // ── Fetch single post (detail modal) ───
      .addCase(fetchPostById.pending, (state) => {
        state.postDetailLoading = true;
        state.postDetailError = null;
        state.postDetail = null;
      })
      .addCase(fetchPostById.fulfilled, (state, action) => {
        state.postDetailLoading = false;
        state.postDetail = action.payload;
      })
      .addCase(fetchPostById.rejected, (state, action) => {
        state.postDetailLoading = false;
        state.postDetailError = action.payload ?? { message: 'Could not load this post.' };
      })

      // ── Fetch Feed ─────────────────────────
      .addCase(fetchFeedPosts.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(fetchFeedPosts.fulfilled, (state, action) => {
        const { posts, total, page, hasMore } = action.payload;
        state.loading = false;
        state.posts = page === 1 ? posts : [...state.posts, ...posts];
        state.feedTotal = total;
        state.feedPage = page;
        state.feedHasMore = hasMore;
      })
      .addCase(fetchFeedPosts.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload;
      })

      // ── Fetch My Posts (profile feed) ─────────
      .addCase(fetchMyPosts.pending, (state) => { state.myPostsLoading = true; })
      .addCase(fetchMyPosts.fulfilled, (state, action) => {
        const { posts, total, page, hasMore } = action.payload;
        state.myPostsLoading = false;
        state.myPosts = page === 1 ? posts : [...state.myPosts, ...posts];
        state.myPostsTotal = total;
        state.myPostsHasMore = hasMore;
      })
      .addCase(fetchMyPosts.rejected, (state) => { state.myPostsLoading = false; })

      // ── Fetch My Posts Count (navbar stat only) ────
      .addCase(fetchMyPostsCount.fulfilled, (state, action) => {
        state.myPostsTotal = action.payload.total;
      })

      // ── Like / React (optimistic) ────────────
      .addCase(likePost.pending, (state, action) => {
        const { postId, userId, reaction = 'like', remove = false } = action.meta.arg;
        state.likingIds.push(postId);
        forEachMatchingPost(state, postId, (post) => {
          const has = post.likes.includes(userId);
          if (remove) {
            // Toggle off: drop the reaction entirely.
            if (has) { post.likes.splice(post.likes.indexOf(userId), 1); post.likesCount = Math.max(0, post.likesCount - 1); }
            post.myReaction = null;
          } else {
            // Add (new) or switch (already reacted → count unchanged).
            if (!has) { post.likes.push(userId); post.likesCount += 1; }
            post.myReaction = reaction;
          }
        });
      })
      .addCase(likePost.fulfilled, (state, action) => {
        const { postId, likesCount, recentReactors, myReaction } = action.payload;
        state.likingIds = state.likingIds.filter(id => id !== postId);
        forEachMatchingPost(state, postId, (post) => {
          if (typeof likesCount === 'number') post.likesCount = likesCount;
          if (Array.isArray(recentReactors)) post.recentReactors = recentReactors;
          post.myReaction = myReaction ?? null;
        });
      })
      .addCase(likePost.rejected, (state, action) => {
        const { postId } = action.meta.arg;
        state.likingIds = state.likingIds.filter(id => id !== postId);
      })

      // ── Comment ────────────────────────────
      .addCase(commentPost.pending, (state, action) => {
        state.commentingId = action.meta.arg.postId;
      })
      .addCase(commentPost.fulfilled, (state, action) => {
        const { postId, comment } = action.payload;
        state.commentingId = null;
        if (comment) {
          const commentId = comment._id ?? comment.id;
          forEachMatchingPost(state, postId, (post) => {
            if (!Array.isArray(post.comments)) post.comments = [];
            // Drop our own optimistic placeholder (addCommentRealtime, marked
            // `pending: true`) now that the real, server-confirmed comment is
            // here — otherwise both would render as two separate comments.
            const hadPending = post.comments.some(c => c?.pending);
            post.comments = post.comments.filter(c => !c?.pending);
            // The live comment:created socket echo of this same comment can
            // land before this REST response does — if it already pushed it
            // (via addCommentRealtime), don't push a second copy here.
            const alreadyPresent = commentId && post.comments.some(c => c && (c._id ?? c.id) === commentId);
            if (!alreadyPresent) {
              post.comments.push(comment);
              if (!hadPending) post.commentsCount = (post.commentsCount ?? 0) + 1;
            }
          });
        }
      })
      .addCase(commentPost.rejected, (state) => {
        state.commentingId = null;
      })

      // ── Fetch full comments for a post (on-demand) ──
      .addCase(fetchPostComments.pending, (state, action) => {
        state.commentsLoadingIds.push(action.meta.arg);
      })
      .addCase(fetchPostComments.fulfilled, (state, action) => {
        const { postId, comments } = action.payload;
        state.commentsLoadingIds = state.commentsLoadingIds.filter(id => id !== postId);
        forEachMatchingPost(state, postId, (post) => mergeFreshComments(post, comments));
      })
      .addCase(fetchPostComments.rejected, (state, action) => {
        const postId = action.payload?.postId ?? action.meta.arg;
        state.commentsLoadingIds = state.commentsLoadingIds.filter(id => id !== postId);
      })

      // ── Silent background comment resync (see syncPostComments above) ──
      .addCase(syncPostComments.fulfilled, (state, action) => {
        const { postId, comments } = action.payload;
        forEachMatchingPost(state, postId, (post) => mergeFreshComments(post, comments));
      })

      // ── Reactions modal — full likes list (paginated) ──
      .addCase(fetchPostLikes.pending, (state, action) => {
        const { postId } = action.meta.arg;
        if (!state.postLikes[postId]) state.postLikes[postId] = { total: 0, items: [], page: 0, hasMore: true, loading: false };
        state.postLikes[postId].loading = true;
      })
      .addCase(fetchPostLikes.fulfilled, (state, action) => {
        const { postId, total, page, likes } = action.payload;
        const entry = state.postLikes[postId] ?? { total: 0, items: [], page: 0, hasMore: true, loading: false };
        entry.total = total;
        entry.page = page;
        entry.items = page === 1 ? likes : [...entry.items, ...likes];
        entry.hasMore = entry.items.length < total;
        entry.loading = false;
        state.postLikes[postId] = entry;
      })
      .addCase(fetchPostLikes.rejected, (state, action) => {
        const postId = action.payload?.postId ?? action.meta.arg?.postId;
        if (state.postLikes[postId]) state.postLikes[postId].loading = false;
      })

      // ── Like a comment/reply ───────────────
      .addCase(likeComment.fulfilled, (state, action) => {
        const { postId, commentId, likesCount } = action.payload;
        forEachMatchingPost(state, postId, (post) => {
          const comment = findComment(post.comments, commentId);
          if (comment && typeof likesCount === 'number') comment.likes = likesCount;
        });
      })

      // ── Reply to a comment ─────────────────
      .addCase(replyToComment.fulfilled, (state, action) => {
        const { postId, commentId, reply } = action.payload;
        if (!reply) return;
        forEachMatchingPost(state, postId, (post) => {
          const comment = post.comments.find(c => (c._id ?? c.id) === commentId);
          if (!comment) return;
          if (!Array.isArray(comment.replies)) comment.replies = [];
          comment.replies.push(reply);
        });
      })

      // ── Edit/delete/report a comment ────────
      .addCase(editComment.fulfilled, (state, action) => {
        const { postId, commentId, text, mentions, editedAt } = action.payload;
        forEachMatchingPost(state, postId, (post) => {
          const c = findComment(post.comments, commentId);
          if (c) { c.text = text; c.mentions = mentions; c.editedAt = editedAt; }
        });
      })
      .addCase(deleteComment.pending, (state, action) => {
        state.deletingCommentId = action.meta.arg.commentId;
      })
      .addCase(deleteComment.fulfilled, (state, action) => {
        state.deletingCommentId = null;
        const { postId, commentId } = action.payload;
        forEachMatchingPost(state, postId, (post) => {
          const c = findComment(post.comments, commentId);
          if (c) { c.deleted = true; c.text = ''; }
          post.commentsCount = Math.max(0, (post.commentsCount ?? 0) - 1);
        });
      })
      .addCase(deleteComment.rejected, (state) => {
        state.deletingCommentId = null;
      })
      .addCase(reportComment.pending, (state) => {
        state.reportSubmitting = true;
      })
      .addCase(reportComment.fulfilled, (state, action) => {
        state.reportSubmitting = false;
        const { postId, commentId } = action.payload;
        forEachMatchingPost(state, postId, (post) => {
          const c = findComment(post.comments, commentId);
          if (c) c.isReported = true;
        });
      })
      .addCase(reportComment.rejected, (state) => {
        state.reportSubmitting = false;
      })

      // ── Edit/delete/report a reply ──────────
      .addCase(editReply.fulfilled, (state, action) => {
        const { postId, replyId, text, mentions, editedAt } = action.payload;
        forEachMatchingPost(state, postId, (post) => {
          const r = findComment(post.comments, replyId);
          if (r) { r.text = text; r.mentions = mentions; r.editedAt = editedAt; }
        });
      })
      .addCase(deleteReply.pending, (state, action) => {
        state.deletingCommentId = action.meta.arg.replyId;
      })
      .addCase(deleteReply.fulfilled, (state, action) => {
        state.deletingCommentId = null;
        const { postId, replyId } = action.payload;
        forEachMatchingPost(state, postId, (post) => {
          const r = findComment(post.comments, replyId);
          if (r) { r.deleted = true; r.text = ''; }
        });
      })
      .addCase(deleteReply.rejected, (state) => {
        state.deletingCommentId = null;
      })
      .addCase(reportReply.pending, (state) => {
        state.reportSubmitting = true;
      })
      .addCase(reportReply.fulfilled, (state, action) => {
        state.reportSubmitting = false;
        const { postId, replyId } = action.payload;
        forEachMatchingPost(state, postId, (post) => {
          const r = findComment(post.comments, replyId);
          if (r) r.isReported = true;
        });
      })
      .addCase(reportReply.rejected, (state) => {
        state.reportSubmitting = false;
      })

      // ── Share ──────────────────────────────
      .addCase(sharePost.pending, (state, action) => {
        const postId = action.meta.arg;
        state.sharingId = postId;
        forEachMatchingPost(state, postId, (post) => {
          if (Array.isArray(post.shares)) post.shares.push('shared');
        });
      })
      .addCase(sharePost.fulfilled, (state, action) => {
        state.sharingId = null;
        const { postId, sharesCount } = action.payload;
        // Trust the server's authoritative count over the optimistic push above.
        if (typeof sharesCount === 'number') {
          forEachMatchingPost(state, postId, (post) => {
            if (Array.isArray(post.shares)) post.shares = new Array(sharesCount).fill(null);
          });
        }
      })
      .addCase(sharePost.rejected, (state, action) => {
        state.sharingId = null;
        const postId = action.meta.arg;
        forEachMatchingPost(state, postId, (post) => {
          if (Array.isArray(post.shares) && post.shares.length > 0) post.shares.pop();
        });
      })

      // ── Edit Post ──────────────────────────
      .addCase(editPost.pending, (state, action) => {
        state.editingId = action.meta.arg.postId;
      })
      .addCase(editPost.fulfilled, (state, action) => {
        state.editingId = null;
        const { postId, caption, visibility, mentions } = action.payload;
        forEachMatchingPost(state, postId, (post) => {
          post.caption = caption;
          post.visibility = visibility;
          post.mentions = mentions;
        });
      })
      .addCase(editPost.rejected, (state) => {
        state.editingId = null;
      })

      // ── Delete Post ────────────────────────
      .addCase(deletePost.pending, (state, action) => {
        state.deletingId = action.meta.arg;
      })
      .addCase(deletePost.fulfilled, (state, action) => {
        state.deletingId = null;
        const { postId } = action.payload;
        state.posts = state.posts.filter(p => p._id !== postId);
        state.myPosts = state.myPosts.filter(p => p._id !== postId);
        state.viewedPosts = state.viewedPosts.filter(p => p._id !== postId);
      })
      .addCase(deletePost.rejected, (state) => {
        state.deletingId = null;
      })

      // ── Create Post ───────────────────────
      .addCase(createPost.pending, (state) => {
        state.creating = true;
      })
      .addCase(createPost.fulfilled, (state, action) => {
        state.creating = false;
        if (action.payload) {
          // Only add to myPosts (user's own posts list)
          // state.posts (feed) will be updated via socket event (post:created)
          state.myPosts.unshift(action.payload);
          state.myPostsTotal += 1;
        }
      })
      .addCase(createPost.rejected, (state) => {
        state.creating = false;
      })

      // ── Report Reasons ─────────────────────
      .addCase(fetchReportReasons.pending, (state) => {
        state.reasonsLoading = true;
      })
      .addCase(fetchReportReasons.fulfilled, (state, action) => {
        state.reasonsLoading = false;
        state.reportReasons = action.payload;
      })
      .addCase(fetchReportReasons.rejected, (state) => {
        state.reasonsLoading = false;
      })

      // ── Report Post ────────────────────────
      .addCase(reportPost.pending, (state) => {
        state.reportSubmitting = true;
      })
      .addCase(reportPost.fulfilled, (state, action) => {
        state.reportSubmitting = false;
        // Session-local until the backend also returns `isReported` on the
        // post itself (GET /api/posts, /api/users/me/posts) — without that,
        // this resets to showing the "..." menu again after a page refresh.
        forEachMatchingPost(state, action.payload.postId, (post) => {
          post.isReported = true;
        });
      })
      .addCase(reportPost.rejected, (state) => {
        state.reportSubmitting = false;
      })

      // ── Report User ────────────────────────
      .addCase(reportUser.pending, (state) => {
        state.reportSubmitting = true;
      })
      .addCase(reportUser.fulfilled, (state) => {
        state.reportSubmitting = false;
      })
      .addCase(reportUser.rejected, (state) => {
        state.reportSubmitting = false;
      })

      // Blocking a user (usersSlice.blockUser) — the backend excludes their
      // posts from GET /api/posts going forward, but that only takes effect
      // on the NEXT fetch; drop their posts from what's already loaded now
      // so blocking has an immediate visible effect instead of waiting for a refetch.
      .addCase(blockUser.fulfilled, (state, action) => {
        const { userId } = action.payload;
        const authorIdOf = (p) => p.author?._id ?? p.author?.id ?? p.authorId ?? p.userId;
        state.posts = state.posts.filter(p => authorIdOf(p) !== userId);
        state.viewedPosts = state.viewedPosts.filter(p => authorIdOf(p) !== userId);
      });
  },
});

export const {
  setViewedPosts,
  clearPostDetail,
  addPostRealtime,
  removePostRealtime,
  updatePostLikeCount,
  addCommentRealtime,
  updateCommentLikeCount,
  updateCommentRealtime,
  deleteCommentRealtime,
  updateReplyRealtime,
  deleteReplyRealtime,
  markPostHiddenRealtime,
} = postsSlice.actions;
export default postsSlice.reducer;
